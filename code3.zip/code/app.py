from flask import Flask
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
@app.route("/")
def homepage():
    return render_template('ECEGroup6.html')

@app.route("/tables")
def tables():
    return render_template('tables.html')

@app.route("/billing")
def billing():
    return render_template('billing.html')

@app.route("/about_us")
def about_us():
    return render_template('about_us.html')


if __name__ == "__main__":
    app.debug = True
    #app.run(host='0.0.0.0',port=8080)
    app.run()
